def despedirse(nombre):
    return "CHAOOOOO " + {nombre} + ", primer paquete de pip..."