def despedirse(nombre):
    return f"CHAOOOOO {nombre}, primer paquete de pip..."